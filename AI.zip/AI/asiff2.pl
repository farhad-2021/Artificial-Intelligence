% Declare male and female individuals
male(asif).
male(monjurul).
male(anjon).
male(rocky).
male(parvez).

female(lina).
female(anita).
female(lita).
female(ruhi).
female(diba).

% Declare parent-child relationships
parent(rocky, ruhi).
parent(rocky, parvez).
parent(asif, monjurul).
parent(asif, anita).
parent(monjurul, lina).
parent(anita, diba).
parent(anita, anjon).
parent(anita, rocky).


% Define relationships

% Father rule: X is the father of Y
father(X, Y) :- parent(X, Y), male(X).

% Mother rule: X is the mother of Y
mother(X, Y) :- parent(X, Y), female(X).

% Grandfather rule: X is the grandfather of Z
grandfather(X, Z) :- parent(X, Y), parent(Y, Z), male(X).

% Grandmother rule: X is the grandmother of Z
grandmother(X, Z) :- parent(X, Y), parent(Y, Z), female(X).

% Sibling rule: X and Y share the same parents
sibling(X, Y) :- parent(Z, X), parent(Z, Y), X \= Y.

% Brother rule: X is the brother of Y
brother(X, Y) :- sibling(X, Y), male(X).

% Sister rule: X is the sister of Y
sister(X, Y) :- sibling(X, Y), female(X).

% Uncle rule: X is the uncle of Y
uncle(X, Y) :- brother(X, Z), parent(Z, Y).

% Predecessor rule: X is an ancestor of Y (recursive)
predecessor(X, Y) :- parent(X, Y).
predecessor(X, Y) :- parent(X, Z), predecessor(Z, Y).

% Wife rule: X is the wife of Y
wife(X, Y) :- parent(X, Z), parent(Y, Z), female(X), male(Y).
