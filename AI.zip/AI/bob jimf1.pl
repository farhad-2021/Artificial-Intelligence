
male(bob).
male(tom).
male(peter).
male(jim).

female(liza).
female(amanita).
female(nipa).
female(pam).

parent(bob, jim).
parent(bob, pam).
parent(amanita, jim).
parent(amanita, pam).
parent(jim, liza).
parent(pam, peter).
parent(pam, tom).
parent(peter, nipa).



father(X, Y) :- parent(X, Y), male(X).

mother(X, Y) :- parent(X, Y), female(X).


grandfather(X, Z) :- parent(X, Y), parent(Y, Z), male(X).

grandmother(X, Z) :- parent(X, Y), parent(Y, Z), female(X).


sibling(X, Y) :- parent(Z, X), parent(Z, Y), X \= Y.


brother(X, Y) :- sibling(X, Y), male(X).


sister(X, Y) :- sibling(X, Y), female(X).


uncle(X, Y) :- brother(X, Z), parent(Z, Y).

predecessor(X, Y) :- parent(X, Y).
predecessor(X, Y) :- parent(X, Z), predecessor(Z, Y).

wife(X, Y) :- parent(X, Z), parent(Y, Z), female(X), male(Y).









