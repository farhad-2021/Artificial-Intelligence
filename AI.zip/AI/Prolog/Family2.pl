male(Asif).
male(Monjurul).
male(Anjon).
male(Rocky).
male(Parvez).


female(Lina).
female(Anita).
female(Diba).
female(Ruhi).

parents(Asif,Monjurul).
parents(Monjurul,Lina).
parents(Asif,Anita).
parents(Rocky,Ruhi).
parents(Rocky,Parvez).

