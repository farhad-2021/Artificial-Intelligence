initial(state(left, left, left, left)).
goal(state(right, right, right, right)).

move(state(F, F, G, C), state(O, O, G, C), 'Farmer takes wolf') :- opp(F, O).
move(state(F, W, F, C), state(O, W, O, C), 'Farmer takes goat') :- opp(F, O).
move(state(F, W, G, F), state(O, W, G, O), 'Farmer takes cabbage') :- opp(F, O).
move(state(F, W, G, C), state(O, W, G, C), 'Farmer moves alone') :- opp(F, O).

opp(left, right). opp(right, left).

safe(state(F, W, G, C)) :- (F = G ; F = W), (F = G ; F = C).

solve :- initial(S), path(S, []).

path(S, _) :- goal(S), write('Solved!'), nl.
path(S, V) :-
    move(S, N, A), safe(N), \+ member(N, V),
    write(A), write(': '), write(N), nl,
    path(N, [N|V]).
